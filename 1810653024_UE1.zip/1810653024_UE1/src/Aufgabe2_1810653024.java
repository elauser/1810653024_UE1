public class Aufgabe2_1810653024 {
    public static void main(String [] args) {
        String name; //character Array (Zeichenkette) 2^31-1 Zeichen
        int alter; //32 bit -2.147.483.648 bis 2.147.483.647
        double kommazahl; //64 bit fliesskomma +/-4,9E-324 bis +/-1,7E+308
        boolean truefalse; //true oder false boolscher wahrheitswert
        long longint; //64 bit -2^63 bis 2^63-1,
        char character; //16 bit Unicode Zeichen(UTF-16)
        byte einbyte; //8 bit -128 bis 127
        short kurz; //16 bit  -32.768 bis 32.767
        float fliesskomma; //32 bit fliesskomma +/-1,4E-45 bis +/-3,4E+38

        name="Matthias Oberleitner";
        alter=21;
        kommazahl=3.141592653589793;
        truefalse= true;
        longint=747474774;
        character='A';
        einbyte=127;
        kurz=22222;
        fliesskomma=31.41f;

        final int KONSTANTE = 218; //Variablen können im Gegensatz zu Konstanten nach der Initialisierung verändert werden.
    }
}
