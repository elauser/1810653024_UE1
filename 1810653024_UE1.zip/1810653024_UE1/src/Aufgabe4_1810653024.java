public class Aufgabe4_1810653024 {
    public static void main(String [] args){
        int zahl1 = 1;
        int zahl2 = 2;

        System.out.println(zahl1<zahl2);
        System.out.println(zahl2<zahl1);
        System.out.println(zahl1>zahl2);
        System.out.println(zahl2>zahl1);
        System.out.println(zahl1<=zahl2);
        System.out.println(zahl2<=zahl1);
        System.out.println(zahl1>=zahl2);
        System.out.println(zahl2>=zahl1);
        System.out.println(zahl1==zahl2);
        System.out.println(zahl1!=zahl2);
    }
}
