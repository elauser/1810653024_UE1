public class Aufgabe3_1810653024 {
    public static void main(String [] args){
        int zahl1=1;
        int zahl2=2;
        int zahl3=3;

        double zahl4=4;
        double zahl5=5;
        double zahl6=6;

        System.out.println(zahl1+zahl2);
        System.out.println(zahl4/zahl3);
        System.out.println(zahl4*zahl2);
        System.out.println(zahl1%zahl2);
        System.out.println(zahl3++);
        System.out.println(zahl2--);
    }
}
