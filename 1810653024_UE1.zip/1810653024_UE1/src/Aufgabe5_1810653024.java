public class Aufgabe5_1810653024 {
    public static void main(String[] args){
        int zahl1 = 1;
        int zahl2 = 2;

        System.out.println(zahl1++);
        System.out.println(zahl2++);
        System.out.println(zahl1);
        System.out.println(zahl2);
        System.out.println(++zahl1);
        System.out.println(++zahl2);
        System.out.println(zahl1);
        System.out.println(zahl2);
        /*
        Bei(variable)++ wird die Zahl nach der Ausgabe erhöht, bei ++(variable) wird sie vorher erhöht.
         */
    }
}
